# FreeSolv 源标签单位纠正

2026-09-18，实测中发现 DeepChem 2.8.0 的 `load_freesolv` 下载的是 `freesolv.csv.gz`，其中 `y` 已经过全数据集 z-score 标准化。

与原始 MoleculeNet `SAMPL.csv` 逐行比较：

- 两者 642 行 SMILES 顺序完全相同。
- 原始 `expt` 均值 -3.8030062305295944 kcal/mol，总体标准差 3.844822204602953 kcal/mol。
- 压缩文件 `y` 均值约 0，总体标准差约 1。
- `(expt - mean(expt)) / std(expt)` 与 `y` 的最大绝对差 2.6645352591003757e-15。

因此不能把 `freesolv.csv.gz` 的 RMSE 标成 kcal/mol。该错误会制造大约 3.845 倍的虚假性能改善。

处理：停止最初的 `results-remaining` 运行，保留其日志和结果用于诊断，不纳入任何最终统计。改用原始 `SAMPL.csv` 的 `expt`，通过 DeepChem 原生 CSVLoader 读入；其他分子特征、模型、划分、训练参数不变，只用训练集拟合目标标准化。重新运行到 `results-corrected`，不会覆盖错误运行，也不会覆盖已经完成的 ESOL 实验。

来源：

- https://github.com/deepchem/deepchem/blob/2.8.0/deepchem/molnet/load_function/freesolv_dataset.py
- https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/SAMPL.csv
- https://github.com/MobleyLab/FreeSolv/blob/master/database.txt （原始实验值单位定义为 kcal/mol）

这是数据表示的纠正，不是模型调参。`experiment.json` 的物理单位、模型和随机种子协议保持不变，代码哈希与该纠正记录保留。
